package FixtheWorld

class sprmlocation(var sprmlft:Double, var sprmrght: Double) {

}
