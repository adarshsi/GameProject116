package FixtheWorld

class Sperm (loc: sprmlocation) {
  var location = loc
}
